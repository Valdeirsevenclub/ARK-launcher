package org.arkikeskus.launcher.feature.backup

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.flowWithLifecycle
import kotlinx.coroutines.flow.collectLatest
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

@Composable
fun BackupScreen(
    onBack: () -> Unit,
    modifier: Modifier = Modifier,
    viewModel: BackupViewModel = hiltViewModel(),
) {
    BackHandler(onBack = onBack)
    val context = LocalContext.current
    val snackbar = remember { SnackbarHostState() }

    // --- File-import state (rememberSaveable: the confirm dialog must survive rotation) ---
    var pendingImport by rememberSaveable { mutableStateOf<android.net.Uri?>(null) }
    val localLastBackupMs by viewModel.localLastBackupMs.collectAsStateWithLifecycle()

    // --- File launchers ---
    val createDoc = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json"),
    ) { uri -> if (uri != null) viewModel.exportTo(uri) }

    val openDoc = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument(),
    ) { uri -> if (uri != null) pendingImport = uri }

    // --- Event handler ---
    val restoredMsg = stringResource(R.string.backup_restored)
    val invalidMsg = stringResource(R.string.backup_import_invalid)
    val tooLargeMsg = stringResource(R.string.backup_error_too_large)
    val failedMsg = stringResource(R.string.backup_failed)
    val exportedMsg = stringResource(R.string.backup_exported)
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    LaunchedEffect(Unit) {
        viewModel.events.flowWithLifecycle(lifecycle).collectLatest { e ->
            snackbar.showMessage(
                when (e) {
                    is BackupEvent.Exported -> exportedMsg
                    is BackupEvent.Restored ->
                        if (e.skipped > 0) {
                            context.resources.getQuantityString(
                                R.plurals.backup_restored_skipped, e.skipped, e.skipped,
                            )
                        } else {
                            restoredMsg
                        }
                    BackupEvent.InvalidFile -> invalidMsg
                    BackupEvent.TooLarge -> tooLargeMsg
                    is BackupEvent.Failed -> if (e.message.isBlank()) failedMsg else "$failedMsg: ${e.message}"
                },
            )
        }
    }

    Scaffold(modifier = modifier.fillMaxSize(), snackbarHost = { SnackbarHost(snackbar) }) { pad ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(pad)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text(stringResource(R.string.backup_title), style = MaterialTheme.typography.headlineMedium)

            // --- File section ---
            Text(stringResource(R.string.backup_file_section), style = MaterialTheme.typography.titleMedium)
            val backupDefaultName = stringResource(R.string.backup_default_name)
            Button(
                onClick = { createDoc.launch(backupFileName(backupDefaultName, LocalDateTime.now())) },
                modifier = Modifier.fillMaxWidth(),
            ) { Text(stringResource(R.string.backup_export)) }
            OutlinedButton(
                onClick = { openDoc.launch(arrayOf("application/json")) },
                modifier = Modifier.fillMaxWidth(),
            ) { Text(stringResource(R.string.backup_import)) }
            if (localLastBackupMs > 0L) {
                val formatted = java.text.DateFormat.getDateTimeInstance(
                    java.text.DateFormat.SHORT,
                    java.text.DateFormat.SHORT,
                ).format(java.util.Date(localLastBackupMs))
                Text(
                    stringResource(R.string.backup_last_time, formatted),
                    style = MaterialTheme.typography.bodySmall,
                )
            }
        }
    }

    // --- File import confirm dialog ---
    pendingImport?.let { uri ->
        AlertDialog(
            onDismissRequest = { pendingImport = null },
            title = { Text(stringResource(R.string.backup_restore_confirm_title)) },
            text = { Text(stringResource(R.string.backup_restore_confirm_msg)) },
            confirmButton = {
                TextButton(onClick = { viewModel.importFrom(uri); pendingImport = null }) {
                    Text(stringResource(R.string.backup_restore_confirm_ok))
                }
            },
            dismissButton = {
                TextButton(onClick = { pendingImport = null }) { Text(stringResource(R.string.backup_cancel)) }
            },
        )
    }
}

private suspend fun SnackbarHostState.showMessage(msg: String) { showSnackbar(msg) }

/** The suggested export name: [base] plus when the backup was made, so a new export never offers
 *  the previous one's name. ASCII digits in every locale, and no characters a file system rejects. */
internal fun backupFileName(base: String, now: LocalDateTime): String =
    "$base-${now.format(BACKUP_NAME_TIME)}.json"

private val BACKUP_NAME_TIME = DateTimeFormatter.ofPattern("yyyy-MM-dd_HH-mm", Locale.ROOT)
