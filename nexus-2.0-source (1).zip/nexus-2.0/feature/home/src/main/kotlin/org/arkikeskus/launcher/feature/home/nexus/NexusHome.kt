package org.arkikeskus.launcher.feature.home.nexus

import android.content.Intent
import android.provider.Settings
import android.widget.Toast
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.repeatOnLifecycle
import kotlinx.coroutines.delay
import org.arkikeskus.launcher.model.AppItem
import org.arkikeskus.launcher.model.NexusCommand
import org.arkikeskus.launcher.model.NexusCommands
import org.arkikeskus.launcher.ui.component.AppIcon
import org.arkikeskus.launcher.designsystem.NexusTheme
import org.arkikeskus.launcher.designsystem.NexusPalette.Violet
import org.arkikeskus.launcher.designsystem.NexusPalette.Cyan
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

/** Real ARK apps and explicit contexts over a separate, scrollable activity surface. */
@Composable
fun NexusHome(
    onOpenDrawer: () -> Unit,
    onOpenWorkspace: () -> Unit,
    onOpenSettings: () -> Unit,
    viewModel: NexusViewModel = hiltViewModel(),
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val badges by viewModel.badges.collectAsStateWithLifecycle()
    val appearance by viewModel.appearance.collectAsStateWithLifecycle()
    val message by viewModel.message.collectAsStateWithLifecycle()
    val busy by viewModel.busy.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    var tab by rememberSaveable { mutableStateOf("Hoje") }
    var editor by rememberSaveable { mutableStateOf<String?>(null) }
    var expanded by rememberSaveable { mutableStateOf(true) }
    var query by rememberSaveable { mutableStateOf("") }
    var backendOpen by rememberSaveable { mutableStateOf(false) }
    // Credentials stay in this composition's memory: never DataStore, SavedState, backup or APK.
    var token by remember { mutableStateOf("") }
    var endpoint by remember(state.preferences.endpoint) { mutableStateOf(state.preferences.endpoint) }
    var date by remember { mutableStateOf(LocalDate.now()) }
    LaunchedEffect(lifecycleOwner) {
        lifecycleOwner.lifecycle.repeatOnLifecycle(Lifecycle.State.RESUMED) {
            while (true) { date = LocalDate.now(); delay(60000) }
        }
    }
    fun openIntent(intent: Intent) {
        if (runCatching { context.startActivity(intent) }.isFailure)
            Toast.makeText(context, "Nenhum aplicativo disponível para esta ação.", Toast.LENGTH_SHORT).show()
    }
    fun localCommand() {
        when (val command = NexusCommands.parse(query)) {
            NexusCommand.Drawer -> onOpenDrawer()
            NexusCommand.Calendar -> openIntent(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_CALENDAR))
            NexusCommand.Settings -> openIntent(Intent(Settings.ACTION_SETTINGS))
            is NexusCommand.Search -> query = command.query
        }
    }
    NexusTheme {
        Surface(color = Color.Black, modifier = Modifier.fillMaxSize()) {
            LazyColumn(
                modifier = Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF17102B), Color.Black)))
                    .safeDrawingPadding().imePadding(),
                contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp),
            ) {
                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("NEXUS", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                            Text(date.format(DateTimeFormatter.ofPattern("EEEE, d MMMM", Locale("pt", "BR"))),
                                style = MaterialTheme.typography.labelMedium, color = Cyan)
                        }
                        TextButton(onClick = onOpenSettings) { Text("Ajustes") }
                    }
                }
                item {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilledTonalButton(onClick = onOpenDrawer, modifier = Modifier.weight(1f)) { Text("Aplicativos") }
                        OutlinedButton(onClick = onOpenWorkspace, modifier = Modifier.weight(1f)) { Text("Meu espaço") }
                    }
                    Text("Widgets, pastas e páginas no Meu espaço", style = MaterialTheme.typography.labelSmall,
                        color = Color(0xFFBAB5CF), modifier = Modifier.padding(top = 6.dp))
                }
                item {
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("Hoje", "Trabalho", "Pessoal", "Continuar").forEach { title ->
                            FilterChip(selected = tab == title, onClick = { tab = title; expanded = true }, label = { Text(title) })
                        }
                    }
                }
                item {
                    NexusCard {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("ATIVIDADES CONECTADAS", color = Cyan, style = MaterialTheme.typography.labelSmall)
                                Text(tab, style = MaterialTheme.typography.headlineSmall)
                            }
                            TextButton(onClick = { expanded = !expanded }) { Text(if (expanded) "Recolher" else "Expandir") }
                        }
                        if (expanded) {
                            val selected = when (tab) {
                                "Trabalho" -> state.apps.filter { it.key in state.preferences.work }
                                "Pessoal" -> state.apps.filter { it.key in state.preferences.personal }
                                else -> state.recent
                            }
                            Text(when (tab) {
                                "Trabalho", "Pessoal" -> "Aplicativos que você escolheu para este contexto."
                                "Continuar" -> "Abertos por este launcher. Toque para reabrir o aplicativo."
                                else -> "Sua agenda e aplicativos abertos recentemente."
                            }, style = MaterialTheme.typography.bodySmall, color = Color(0xFFC4BED6))
                            if (tab == "Hoje") OutlinedButton(onClick = {
                                openIntent(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_CALENDAR))
                            }) { Text("Abrir agenda") }
                            if (selected.isEmpty()) Text(if (tab == "Trabalho" || tab == "Pessoal")
                                "Nenhum aplicativo escolhido. Personalize seu contexto abaixo."
                                else "Os aplicativos aparecerão aqui conforme você os abrir pelo launcher.",
                                modifier = Modifier.padding(vertical = 12.dp), style = MaterialTheme.typography.bodyMedium)
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                items(selected, key = { it.key }) { app ->
                                    AppIcon(appItem = app, labelColor = Color.White,
                                        badgeCount = if (appearance.showNotificationDots) badges[app.badgeKey] ?: 0 else 0,
                                        badgeShowCount = appearance.notificationDotCount,
                                        badgeScale = appearance.notificationDotScale,
                                        modifier = Modifier.width(78.dp).clickable { viewModel.launch(app) }.padding(4.dp))
                                }
                            }
                            if (tab == "Trabalho" || tab == "Pessoal")
                                TextButton(onClick = { editor = tab }) { Text("Escolher aplicativos") }
                        }
                    }
                }
                item {
                    NexusCard {
                        Text("✦  Assistente Nexus", style = MaterialTheme.typography.titleLarge, color = Cyan)
                        Text("Busque um app ou digite: abrir agenda, configurações, aplicativos.",
                            style = MaterialTheme.typography.bodySmall)
                        OutlinedTextField(value = query, onValueChange = { query = it.take(4000) },
                            label = { Text("O que você quer fazer?") }, modifier = Modifier.fillMaxWidth(), maxLines = 3)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { localCommand() }, enabled = query.isNotBlank()) { Text("Buscar / abrir") }
                            TextButton(onClick = { backendOpen = !backendOpen }) { Text("Backend IA") }
                        }
                        if (backendOpen) {
                            Text("Somente sua mensagem será enviada ao servidor configurado. Use um token de sessão do seu backend; mantenha a chave do modelo no servidor.",
                                style = MaterialTheme.typography.bodySmall)
                            OutlinedTextField(value = endpoint, onValueChange = { endpoint = it.take(2048) },
                                label = { Text("Endpoint HTTPS") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                            TextButton(onClick = { viewModel.saveEndpoint(endpoint) }) { Text("Salvar endereço") }
                            OutlinedTextField(value = token, onValueChange = { token = it.take(4096) },
                                label = { Text("Token de sessão (somente em memória)") },
                                visualTransformation = PasswordVisualTransformation(), singleLine = true, modifier = Modifier.fillMaxWidth())
                            Button(onClick = { viewModel.ask(query, token) }, enabled = !busy && query.isNotBlank() && state.preferences.endpoint.isNotBlank()) {
                                Text(if (busy) "Consultando…" else "Enviar mensagem ao backend")
                            }
                            TextButton(onClick = { token = ""; viewModel.saveEndpoint(""); endpoint = "" }) { Text("Desconectar") }
                        }
                        if (message.isNotBlank()) Text(message, style = MaterialTheme.typography.bodyMedium)
                    }
                }
                val search = (NexusCommands.parse(query) as? NexusCommand.Search)?.query.orEmpty()
                if (search.isNotBlank()) {
                    val matches = state.apps.filter { NexusCommands.normalize(it.label).contains(search) }.take(30)
                    if (matches.isEmpty()) item { Text("Nenhum aplicativo encontrado.") }
                    items(matches, key = { "search/${it.key}" }) { app ->
                        Surface(shape = RoundedCornerShape(20.dp), onClick = { viewModel.launch(app) }) {
                            Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                                AppIcon(appItem = app, labelColor = Color.White, iconSize = 36.dp, showLabel = false)
                                Text(app.label, Modifier.weight(1f))
                                Text("Abrir", color = Cyan)
                            }
                        }
                    }
                }
            }
        }
        editor?.let { title ->
            var filter by remember { mutableStateOf("") }
            AlertDialog(onDismissRequest = { editor = null }, title = { Text("Aplicativos · $title") },
                text = {
                    Column {
                        OutlinedTextField(value = filter, onValueChange = { filter = it }, label = { Text("Filtrar aplicativos") })
                        LazyColumn(Modifier.heightIn(max = 380.dp)) {
                            items(state.apps.filter { NexusCommands.normalize(it.label).contains(NexusCommands.normalize(filter)) }, key = { it.key }) { app ->
                                val selected = app.key in if (title == "Trabalho") state.preferences.work else state.preferences.personal
                                Row(Modifier.fillMaxWidth().clickable { viewModel.toggle(app, title == "Trabalho") }.padding(8.dp),
                                    verticalAlignment = Alignment.CenterVertically) {
                                    Checkbox(checked = selected, onCheckedChange = { viewModel.toggle(app, title == "Trabalho") })
                                    Text(app.label)
                                }
                            }
                        }
                    }
                }, confirmButton = { TextButton(onClick = { editor = null }) { Text("Concluído") } })
        }
    }
}

@Composable
private fun NexusCard(content: @Composable ColumnScope.() -> Unit) {
    Surface(shape = RoundedCornerShape(28.dp), color = Color(0xDD171725),
        border = BorderStroke(1.dp, Violet.copy(alpha = .28f)), modifier = Modifier.fillMaxWidth().animateContentSize()) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp), content = content)
    }
}
