package org.arkikeskus.launcher.feature.home.nexus

import android.os.Process
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import org.arkikeskus.launcher.data.*
import org.arkikeskus.launcher.model.AppItem
import org.arkikeskus.launcher.model.LauncherSettings
import javax.inject.Inject

data class NexusState(
    val apps: List<AppItem> = emptyList(),
    val recent: List<AppItem> = emptyList(),
    val preferences: NexusPreferences = NexusPreferences(),
)

@HiltViewModel
class NexusViewModel @Inject constructor(
    private val apps: AppRepository,
    private val repository: NexusRepository,
    settings: SettingsRepository,
    usage: AppUsageRepository,
    notifications: NotificationBadgeRepository,
    private val backend: NexusBackendClient,
) : ViewModel() {
    val appearance = settings.settings.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), LauncherSettings())
    val state = combine(apps.apps, settings.hiddenApps, usage.usage, repository.preferences) { all, hidden, history, preferences ->
        // Private Space and managed profiles remain in ARK's profile-aware drawer. Never leak them
        // into a persistent context or search when their profile has been locked or paused.
        val visible = all.filter { it.key !in hidden && !it.isHidden && it.user == Process.myUserHandle() }
        NexusState(visible, visible.filter { it.key in history }.sortedByDescending { history[it.key]?.lastUsed }.take(8), preferences)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), NexusState())
    val badges = notifications.badges
    private val _message = MutableStateFlow("")
    val message = _message.asStateFlow()
    private val _busy = MutableStateFlow(false)
    val busy = _busy.asStateFlow()

    fun launch(app: AppItem) {
        // Revalidate against the visible snapshot before any launch.
        if (state.value.apps.none { it.key == app.key }) return
        if (apps.launch(app).isFailure) _message.value = "Não foi possível abrir este aplicativo."
    }
    fun toggle(app: AppItem, work: Boolean) = viewModelScope.launch {
        try { repository.toggle(app.key, work) }
        catch (e: CancellationException) { throw e }
        catch (_: Exception) { _message.value = "Não foi possível salvar o contexto." }
    }
    fun saveEndpoint(endpoint: String) = viewModelScope.launch {
        try {
            repository.setEndpoint(endpoint.trim())
            _message.value = "Endereço salvo. Somente o texto enviado será compartilhado."
        } catch (e: CancellationException) { throw e }
        catch (_: Exception) { _message.value = "Endereço inválido. Use HTTPS sem credenciais ou parâmetros." }
    }
    fun ask(message: String, token: String) {
        if (_busy.value || message.isBlank()) return
        val endpoint = state.value.preferences.endpoint
        if (endpoint.isBlank()) { _message.value = "Configure seu backend HTTPS antes de enviar."; return }
        viewModelScope.launch {
            _busy.value = true
            try { _message.value = backend.reply(endpoint, token, message) }
            catch (e: CancellationException) { throw e }
            catch (_: Exception) { _message.value = "Não foi possível consultar o backend. Verifique o endereço, a sessão e a conexão." }
            finally { _busy.value = false }
        }
    }
}
