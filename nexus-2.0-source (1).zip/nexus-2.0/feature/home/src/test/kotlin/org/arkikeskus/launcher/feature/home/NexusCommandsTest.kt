package org.arkikeskus.launcher.feature.home

import org.arkikeskus.launcher.model.NexusCommand
import org.arkikeskus.launcher.model.NexusCommands
import org.junit.Assert.*
import org.junit.Test

class NexusCommandsTest {
    @Test fun commandsAcceptAccentsAndWhitespace() {
        assertEquals(NexusCommand.Settings, NexusCommands.parse("  CONFIGURAÇÕES  "))
        assertEquals(NexusCommand.Calendar, NexusCommands.parse("Abrir calendário"))
        assertEquals(NexusCommand.Drawer, NexusCommands.parse("aplicativos"))
    }

    @Test fun appNamesRemainSearchesRequiringExplicitSelection() {
        assertEquals(NexusCommand.Search("camera"), NexusCommands.parse("abrir Câmera"))
        assertEquals(NexusCommand.Search("banco"), NexusCommands.parse("buscar Banco"))
        assertTrue(NexusCommands.parse("apagar todos os arquivos") is NexusCommand.Search)
    }
}
