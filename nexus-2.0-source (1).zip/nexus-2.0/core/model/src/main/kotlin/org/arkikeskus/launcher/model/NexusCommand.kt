package org.arkikeskus.launcher.model

import java.text.Normalizer
import java.util.Locale

sealed interface NexusCommand {
    data object Drawer : NexusCommand
    data object Calendar : NexusCommand
    data object Settings : NexusCommand
    data class Search(val query: String) : NexusCommand
}

/** Deliberately small local grammar. App results require a tap; ambiguous names never auto-launch. */
object NexusCommands {
    fun normalize(text: String): String = Normalizer.normalize(text.trim(), Normalizer.Form.NFD)
        .replace("\\p{M}+".toRegex(), "").lowercase(Locale.ROOT)

    fun parse(text: String): NexusCommand {
        val normalized = normalize(text)
        return when (normalized) {
            "apps", "aplicativos", "abrir aplicativos" -> NexusCommand.Drawer
            "agenda", "calendario", "abrir agenda", "abrir calendario" -> NexusCommand.Calendar
            "configuracoes", "abrir configuracoes", "ajustes" -> NexusCommand.Settings
            else -> NexusCommand.Search(normalized.removePrefix("abrir ").removePrefix("buscar ").trim())
        }
    }
}
