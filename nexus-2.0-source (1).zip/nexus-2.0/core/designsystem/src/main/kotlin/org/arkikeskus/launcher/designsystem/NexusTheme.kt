package org.arkikeskus.launcher.designsystem

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

object NexusPalette {
    val Violet = Color(0xFF9C89FF)
    val Cyan = Color(0xFF72DDF1)
    val Black = Color.Black
    val Surface = Color(0xFF121321)
}

/** Nexus activities use an AMOLED palette; ARK's configurable workspace theme is preserved. */
@Composable
fun NexusTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(primary = NexusPalette.Violet, secondary = NexusPalette.Cyan,
            background = NexusPalette.Black, surface = NexusPalette.Surface, onSurface = Color(0xFFF0EEFF)),
        content = content,
    )
}
