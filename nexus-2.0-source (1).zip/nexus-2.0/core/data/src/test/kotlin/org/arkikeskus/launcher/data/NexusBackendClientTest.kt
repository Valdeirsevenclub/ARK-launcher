package org.arkikeskus.launcher.data

import org.junit.Assert.*
import org.junit.Test

class NexusBackendClientTest {
    @Test fun endpointRequiresTlsAndRejectsEmbeddedSecrets() {
        assertTrue(NexusBackendClient.validEndpoint("https://example.org/nexus/message"))
        assertFalse(NexusBackendClient.validEndpoint("http://example.org/message"))
        assertFalse(NexusBackendClient.validEndpoint("https://user:secret@example.org/message"))
        assertFalse(NexusBackendClient.validEndpoint("https://example.org/message?key=secret"))
        assertFalse(NexusBackendClient.validEndpoint("https://example.org/message#token"))
        assertFalse(NexusBackendClient.validEndpoint("invalid"))
    }
}
