package org.arkikeskus.launcher.data

import java.net.URI
import java.io.ByteArrayOutputStream
import javax.net.ssl.HttpsURLConnection
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import javax.inject.Inject

/** Backend returns text only. A server response is never interpreted as an executable command. */
interface NexusBackend {
    suspend fun reply(endpoint: String, sessionToken: String, message: String): String
}

class NexusBackendClient @Inject constructor() : NexusBackend {
    override suspend fun reply(endpoint: String, sessionToken: String, message: String): String = withContext(Dispatchers.IO) {
        require(validEndpoint(endpoint)) { "Use um endereço HTTPS sem credenciais ou parâmetros." }
        require(message.isNotBlank() && message.length <= 4000)
        require(sessionToken.length <= 4096 && !sessionToken.contains('\n') && !sessionToken.contains('\r'))
        val connection = URI(endpoint).toURL().openConnection() as HttpsURLConnection
        try {
            connection.requestMethod = "POST"
            connection.instanceFollowRedirects = false
            connection.connectTimeout = 10000
            connection.readTimeout = 20000
            connection.doOutput = true
            connection.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            connection.setRequestProperty("Accept", "application/json")
            if (sessionToken.isNotBlank()) connection.setRequestProperty("Authorization", "Bearer $sessionToken")
            val payload = JSONObject().put("message", message).put("locale", "pt-BR").toString().toByteArray(Charsets.UTF_8)
            connection.setFixedLengthStreamingMode(payload.size)
            connection.outputStream.use { it.write(payload) }
            check(connection.responseCode in 200..299) { "Backend indisponível (HTTP ${connection.responseCode})." }
            val bytes = connection.inputStream.use { input ->
                val output = ByteArrayOutputStream()
                val buffer = ByteArray(4096)
                while (true) {
                    val count = input.read(buffer)
                    if (count < 0) break
                    check(output.size() + count <= 65536) { "Resposta excede o limite permitido." }
                    output.write(buffer, 0, count)
                }
                output.toByteArray()
            }
            check(bytes.size <= 65536) { "Resposta excede o limite permitido." }
            val reply = JSONObject(String(bytes, Charsets.UTF_8)).getString("reply").trim()
            check(reply.isNotEmpty() && reply.length <= 12000) { "Resposta inválida." }
            reply
        } finally {
            connection.disconnect()
        }
    }

    companion object {
        fun validEndpoint(value: String): Boolean = runCatching {
            val uri = URI(value)
            uri.scheme == "https" && !uri.host.isNullOrBlank() && uri.userInfo == null && uri.fragment == null && uri.query == null
        }.getOrDefault(false)
    }
}
