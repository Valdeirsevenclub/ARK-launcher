package org.arkikeskus.launcher.data.local

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * One entry in the home layout. A single table holds three shapes, distinguished by [containerId]
 * and [folderName]:
 *  - **App on home**: [containerId] = [HOME], [folderName] = null, package set, at a home cell.
 *  - **Folder on home**: [containerId] = [HOME], [folderName] != null, package empty, at a home cell.
 *    Its [id] is the container id its children point at.
 *  - **App inside a folder**: [containerId] = the folder's id; [page]/[cellX]/[cellY] are the in-folder
 *    order rather than a home cell.
 *  - **Pinned deep shortcut on home**: [containerId] = [HOME], [shortcutId] != null, [packageName] is
 *    the publishing app, at a home cell. Launched via LauncherApps.startShortcut.
 *
 * The unique index on (containerId, page, cellX, cellY) enforces "one item per cell" *within each
 * container* (the home grid and each folder are independent cell spaces) — see [HomeLayoutRepository].
 */
@Entity(
    tableName = "home_items",
    indices = [Index(value = ["containerId", "page", "cellX", "cellY"], unique = true)],
)
data class HomeItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val containerId: Long = HOME,
    val folderName: String? = null,
    val packageName: String = "",
    val className: String = "",
    val userSerial: Long = 0,
    /** Non-null → this row is a pinned deep shortcut published by [packageName]. */
    val shortcutId: String? = null,
    val page: Int,
    val cellX: Int,
    val cellY: Int,
    val spanX: Int = 1,
    val spanY: Int = 1,
    /** Non-null → this row is a bound app widget occupying spanX×spanY cells. */
    val appWidgetId: Int? = null,
    /** The widget provider's ComponentName.flattenToString() (set when [appWidgetId] is). */
    val widgetProvider: String? = null,
    /** Non-null → a built-in launcher widget (see [BUILTIN_SMARTSPACE]) occupying spanX×spanY cells. */
    val builtinType: String? = null,
) {
    /** Matches AppItem.key so app entities can be resolved against the live app list. */
    val key: String get() = "$packageName/$className/$userSerial"

    val isFolder: Boolean get() = folderName != null

    val isShortcut: Boolean get() = shortcutId != null

    val isWidget: Boolean get() = appWidgetId != null

    val isBuiltin: Boolean get() = builtinType != null

    /** A plain app icon (on home or inside a folder), resolved through [key]. */
    val isApp: Boolean
        get() = folderName == null && shortcutId == null && widgetProvider == null &&
            builtinType == null && packageName.isNotEmpty()

    /** True for any row that occupies a spanX×spanY footprint (an app widget — bound or a restored
     *  placeholder — or a built-in widget); everything else is 1×1. */
    val hasFootprint: Boolean get() = widgetProvider != null || builtinType != null

    companion object {
        /** [containerId] sentinel meaning "placed directly on the home screen". */
        const val HOME = -1L

        /** [builtinType] of the clock + date + next-calendar-event widget. */
        const val BUILTIN_SMARTSPACE = "smartspace"

        /** [builtinType] of the notifications widget (active notifications as app icons). */
        const val BUILTIN_NOTIFICATIONS = "notifications"

        /** [builtinType] of the battery widget (a ring gauge + percent, app-icon sized). */
        const val BUILTIN_BATTERY = "battery"

        /** [builtinType] of the people widget (conversations grouped by person, as quiet tiles). */
        const val BUILTIN_PEOPLE = "people"
    }
}
