package org.arkikeskus.launcher.data

import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

data class NexusPreferences(
    val work: Set<String> = emptySet(),
    val personal: Set<String> = emptySet(),
    val endpoint: String = "",
)

/** Contexts are chosen by the owner, never inferred from package names or private content. */
@Singleton
class NexusRepository @Inject constructor(private val store: DataStore<Preferences>) {
    private val work = stringSetPreferencesKey("nexus_work")
    private val personal = stringSetPreferencesKey("nexus_personal")
    private val endpoint = stringPreferencesKey("nexus_endpoint")
    val preferences = store.data.map { NexusPreferences(it[work].orEmpty(), it[personal].orEmpty(), it[endpoint].orEmpty()) }

    suspend fun toggle(key: String, isWork: Boolean) {
        store.edit { p ->
            val field = if (isWork) work else personal
            val current = p[field].orEmpty()
            p[field] = if (key in current) current - key else current + key
        }
    }

    suspend fun setEndpoint(value: String) {
        require(value.isBlank() || NexusBackendClient.validEndpoint(value))
        store.edit { it[endpoint] = value.trim() }
    }
}
