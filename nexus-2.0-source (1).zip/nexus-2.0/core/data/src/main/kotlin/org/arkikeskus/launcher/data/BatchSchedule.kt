package org.arkikeskus.launcher.data

import java.time.Instant
import java.time.LocalTime
import java.time.ZoneId
import java.util.Locale

/** The people widget's batch delivery times: parsing, formatting and "when is the next one". */
object BatchSchedule {

    /** "HH:mm" entries separated by commas, spaces or semicolons → sorted distinct minutes of day.
     *  Entries that don't parse are dropped; an empty result means "no valid time". */
    fun parse(raw: String): List<Int> =
        raw.split(',', ';', ' ', '\n').mapNotNull { part ->
            val t = part.trim()
            if (t.isEmpty()) return@mapNotNull null
            val m = TIME.matchEntire(t) ?: return@mapNotNull null
            val h = m.groupValues[1].toInt()
            val min = m.groupValues[2].toInt()
            if (h > 23 || min > 59) null else h * 60 + min
        }.distinct().sorted()

    fun format(minutes: List<Int>): String =
        minutes.sorted().joinToString(",") { String.format(Locale.ROOT, "%02d:%02d", it / 60, it % 60) }

    /** Epoch ms of the first delivery strictly after [nowMs] (today or tomorrow); null without times. */
    fun nextDelivery(nowMs: Long, times: List<Int>, zone: ZoneId = ZoneId.systemDefault()): Long? {
        if (times.isEmpty()) return null
        val today = Instant.ofEpochMilli(nowMs).atZone(zone).toLocalDate()
        // Wall-clock times, not "minutes after midnight": on a DST day the two differ by an hour. A
        // time inside the spring gap moves forward past it and an autumn repeat takes the first
        // occurrence (java.time's rules), so the order of the HH:mm values is not the order of the
        // instants — resolve every candidate and take the earliest one ahead.
        return (0L..1L).flatMap { day ->
            val date = today.plusDays(day)
            times.map { t -> date.atTime(LocalTime.of(t / 60, t % 60)).atZone(zone).toInstant().toEpochMilli() }
        }.filter { it > nowMs }.minOrNull()
    }

    private val TIME = Regex("(\\d{1,2})[.:](\\d{2})")
}
