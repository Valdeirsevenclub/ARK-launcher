# Nexus 2.0 — primeira entrega de código

Base: [ARK Launcher](https://github.com/jrs8205/ARK-launcher), revisão
`f01329e4d0d295bbcca6912d6723a0d4e541831b` (main consultada em 23/10/2026).
Licença Apache 2.0; LICENSE e avisos originais preservados. O ZIP recebido continha
apenas uma Home de 5 KB e um script Termux, não o projeto Android completo.
Esta entrega integra uma implementação ampliada ao código original do ARK.

**Estado: código implementado; APK e funcionamento no dispositivo ainda não validados.**
Não houve publicação, push nem execução do GitHub Actions nesta sessão.

## Análise da base e preservação

A árvore completa do repositório foi consultada. Os 423 arquivos de texto foram
transferidos e conferidos pelo hash Git original antes das modificações. O
histórico Git local começa com essa importação; não é um clone do histórico upstream.
Os 23 binários originais foram recuperados pelo conector GitHub em Base64 em
24/10/2026, conferidos pelos hashes Git e incluídos nesta árvore. O manifesto
`upstream-binaries.json` permite verificar sua integridade.

| Módulo | Responsabilidade preservada / integração Nexus |
| --- | --- |
| app | LauncherActivity, HOME/DEFAULT, onboarding, notificações, shell e atividades de configurações. Nome Nexus e applicationId independente. Workflow de APK debug. |
| core/launcher | Integrações Android, gestos, acessibilidade opcional, widgets e indicadores mantidos. Sem root. |
| core/designsystem | Tema original preservado; novo NexusTheme AMOLED para a superfície de atividades. |
| core/data | Room, DataStore, catálogo e abertura de apps, histórico, perfis, calendário, clima e notificações preservados. NexusRepository e cliente HTTPS adicionados. |
| core/model | Modelos originais preservados; gramática local NexusCommands adicionada. |
| core/ui | Ícones, caches, personalização, menus, ações e suporte a arrastar preservados e reutilizados. |
| feature/home | Home original mantida, incluindo páginas, pastas, atalhos, widgets, dock e gerenciamento. NexusHome e NexusViewModel adicionados. |
| feature/appdrawer | Gaveta, pesquisa e perfis mantidos; acessíveis pelo Nexus. |
| feature/settings | Configurações originais mantidas; acessíveis em Ajustes. |
| feature/backup | Exportação e restauração originais preservadas. |
| build-logic | Convenções e versões do ARK preservadas: JDK 21, SDK/target 37, mínimo 30, Gradle 9.6.0. |

Nenhum módulo novo. O alvo original 37 foi mantido; Android 16/API 36 está acima
do mínimo e continua sendo um alvo de execução, mas essa compatibilidade precisa
ser confirmada no Galaxy S23 Ultra. O projeto não foi rebaixado de versões sem build.

## Recursos implementados no código

- Home Nexus rolável, fundo AMOLED, gradientes, cartões arredondados e expansão animada.
- Hoje abre a agenda instalada e mostra apps realmente abertos pelo launcher.
- Trabalho e Pessoal permitem escolher/remover apps; seleções persistem no DataStore.
- Continuar usa AppUsageRepository e reabre os apps pelo AppRepository. Não promete
  restaurar tarefas ou documentos específicos de outros aplicativos.
- Busca ignora acentos; resultados exibem ícones reais e exigem toque para abrir.
- Comandos locais: `abrir agenda`, `configurações`, `aplicativos`, `abrir <nome>` e `buscar <nome>`.
- Meu espaço retorna à Home original para widgets, pastas, atalhos e páginas.
  O botão “NEXUS · Atividades” e HOME quando já no launcher retornam às atividades.
- Nexus é apresentado em uma janela Compose separada para o scroll não interceptar
  os gestos de arrastar widgets do workspace original. Voltar fecha essa superfície.
- Ícones usam o carregamento/cache do ARK e as preferências existentes. Indicadores
  respeitam a opção de notificações. Datas só são atualizadas com a tela retomada.
- Apps ocultos e perfis privados/gerenciados não entram nos contextos Nexus. Os
  perfis continuam disponíveis na gaveta original, com os controles do Android.
- `org.nexus.launcher` (`.debug` no debug) permite instalar separado do ARK. Os
  namespaces Kotlin continuam os do ARK para preservar o código existente.

## Assistente e backend próprio

O assistente local não usa um modelo de IA. A consulta a IA exige um backend
fornecido pelo usuário; não há servidor de IA nem credencial embutidos no APK.

Na Home: Backend IA → preencher URL HTTPS → Salvar endereço → inserir token de
sessão do próprio backend → escrever mensagem → Enviar mensagem ao backend.
O token não deve ser uma chave do provedor do modelo: essa chave fica no servidor.
O token de sessão só fica em memória enquanto essa composição está aberta,
não usa rememberSaveable, DataStore, backup ou logs. Desconectar apaga endereço e token.

Contrato HTTP do endpoint configurado:

```http
POST /nexus/message
Content-Type: application/json; charset=utf-8
Authorization: Bearer <token de sessão, se configurado>

{"message":"texto digitado","locale":"pt-BR"}
```

```json
{"reply":"Resposta textual do backend"}
```

O cliente usa TLS padrão, rejeita HTTP, credenciais na URL, query e fragmento,
não segue redirecionamentos e limita mensagem a 4.000 caracteres, corpo de resposta
a 64 KiB e texto a 12.000 caracteres. Há timeouts e estado de erro/carregamento.
Somente a mensagem é enviada: catálogo, notificações, agenda e histórico não são
anexados. Respostas são texto e nunca comandos executáveis. NexusBackend define
o contrato do motor remoto; NexusBackendClient implementa o transporte;
NexusCommands mantém comandos locais independentes da rede.

O backend real deve validar sessões, autorizar usuários, limitar requisições e
proteger as chaves do provedor. Não há backend de demonstração com dados pessoais fictícios.

## Recuperar arquivos e compilar

O pacote já contém o Gradle Wrapper e os recursos binários originais.
Para verificar os arquivos e compilar em um ambiente com rede:

```sh
python3 scripts/restore_upstream.py
bash ./gradlew testDebugUnitTest lintDebug :app:assembleDebug --stacktrace
```

Alternativa sem download pelo script: obtenha o ARK na revisão acima e execute
`python3 scripts/restore_upstream.py --from-directory /caminho/do/ARK`.
Cada binário é verificado pelo hash Git original antes de ser escrito. São
necessários JDK 21, Android SDK 37, Build Tools 37.0.0 e acesso aos repositórios
Gradle/Google/Maven. O APK, se o build passar, ficará em
`app/build/outputs/apk/debug/app-debug.apk`.

`.github/workflows/nexus-debug.yml` executa em push, PR e manualmente. Verifica
os binários incluídos, instala o SDK, executa testes e lint e compila o debug. O artefato `nexus-2.0-debug` só é enviado depois de o build
passar; relatórios são enviados mesmo em caso de falha. Para obter um link de
download é necessário publicar esta árvore em um repositório GitHub e executar
o workflow. Nenhuma execução remota foi iniciada aqui.

## Validação desta sessão

- Hashes dos 423 arquivos de texto originais conferidos antes das alterações.
- `git diff --check`, parsing XML dos recursos/manifestos, sintaxe Python do
  restaurador e `bash -n gradlew`: executados; detalhes em `validation/`.
- Fluxos do restaurador testados com arquivo válido e arquivo adulterado.
- Testes JUnit adicionados para normalização/comandos locais e URLs inseguras.
- Em 23/10, a tentativa de build parou por falta do wrapper. Em 24/10 esse
  bloqueio foi resolvido: os 23 binários foram recuperados e verificados.
- Nova tentativa real de build em 24/10: o Gradle Wrapper iniciou, mas o download
  da distribuição Gradle 9.6.0 foi bloqueado pelo ambiente (`Operation not permitted`).
- Não foi detectado SDK Android instalado. As dependências de build ainda precisam
  ser baixadas em um ambiente com rede, como o GitHub Actions.
- Testes Kotlin, lint Android e compilação Kotlin ainda não foram executados até
  conclusão. Não há APK gerado. Consulte `validation/android-build.log`.

## Limitações e próximas etapas

1. Executar o workflow, corrigir eventuais erros Kotlin/lint e testar o APK no S23
   Ultra: instalação, launcher padrão, HOME/Voltar, apps, widgets, arrastar, pastas,
   gaveta, perfis bloqueados, permissões negadas e restauração de backup.
2. Validar o backend real com sessão expirada, offline, timeout e respostas inválidas.
3. A referência visual aprovada não foi fornecida; fidelidade visual e medidas
   precisam de revisão em dispositivo. Esta Home usa uma janela Compose sobre o
   workspace original, não substitui toda a navegação do shell nesta entrega.
4. Trabalho é um contexto escolhido pelo usuário, não uma inferência de emprego
   nem leitura do perfil corporativo. Integrações contextuais de calendário,
   resumo de notificações e voz ainda não fazem parte do assistente. O ARK mantém
   seus widgets e permissões existentes para esses dados.
5. A interface nova está em português; internacionalização completa, gestos
   específicos da Home Nexus e testes instrumentados adicionais ficam pendentes.
6. Ainda não é uma versão completa de produção. Não há medição de fluidez,
   consumo ou regressões no dispositivo, nem serviço de IA provisionado.
