#!/usr/bin/env python3
"""Restore unchanged ARK binaries from an exact upstream checkout or HTTPS raw files."""
import argparse
import hashlib
import json
import pathlib
import urllib.request

ROOT = pathlib.Path(__file__).resolve().parents[1]
REVISION = "f01329e4d0d295bbcca6912d6723a0d4e541831b"


def blob_hash(data):
    return hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--from-directory", type=pathlib.Path)
    args = parser.parse_args()
    manifest = json.loads((ROOT / "upstream-binaries.json").read_text())
    for entry in manifest:
        target = ROOT / entry["path"]
        if target.exists() and blob_hash(target.read_bytes()) == entry["sha"]:
            continue
        if args.from_directory:
            data = (args.from_directory / entry["path"]).read_bytes()
        else:
            url = f"https://raw.githubusercontent.com/jrs8205/ARK-launcher/{REVISION}/{entry['path']}"
            with urllib.request.urlopen(url, timeout=15) as response:
                data = response.read()
        if blob_hash(data) != entry["sha"]:
            raise SystemExit(f"Upstream hash mismatch: {entry['path']}")
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
    print(f"Verified {len(manifest)} upstream binary files.")


if __name__ == "__main__":
    main()
